import '../models/shape_info.dart';

final List<ShapeInfo> shapeList = [
  ShapeInfo(
    name: "Acute Triangle",
    image: "assets/images/acute_triangle.png",
    description: "A triangle with all angles less than 90°.",
  ),
  ShapeInfo(
    name: "Obtuse Triangle",
    image: "assets/images/obtuse_triangle.png",
    description: "A triangle with one angle greater than 90°.",
  ),
  ShapeInfo(
    name: "Right Triangle",
    image: "assets/images/right_triangle.png",
    description: "A triangle with one 90° angle.",
  ),
  ShapeInfo(
    name: "Equilateral Triangle",
    image: "assets/images/equilateral_triangle.png",
    description: "All sides and angles are equal.",
  ),
  ShapeInfo(
    name: "Isosceles Triangle",
    image: "assets/images/isosceles_triangle.png",
    description: "Two sides and two angles are equal.",
  ),
  ShapeInfo(
    name: "Scalene Triangle",
    image: "assets/images/scalene_triangle.png",
    description: "All sides and angles are different.",
  ),
  ShapeInfo(
    name: "Square",
    image: "assets/images/square.png",
    description: "Four equal sides and right angles.",
  ),
  ShapeInfo(
    name: "Rectangle",
    image: "assets/images/rectangle.png",
    description: "Opposite sides equal and four right angles.",
  ),
  ShapeInfo(
    name: "Rhombus",
    image: "assets/images/rhombus.png",
    description: "All sides equal, opposite angles equal.",
  ),
  ShapeInfo(
    name: "Kite",
    image: "assets/images/kite.png",
    description: "Two pairs of adjacent equal sides.",
  ),
  ShapeInfo(
    name: "Trapezoid",
    image: "assets/images/trapezoid.png",
    description: "One pair of parallel sides.",
  ),
  ShapeInfo(
    name: "Isosceles Trapezium",
    image: "assets/images/isosceles_trapezium.png",
    description: "Non-parallel sides are equal in length.",
  ),
  ShapeInfo(
    name: "Parallelogram",
    image: "assets/images/parallelogram.png",
    description: "Opposite sides parallel and equal.",
  ),
  ShapeInfo(
    name: "Pentagon",
    image: "assets/images/pentagon.png",
    description: "5 sides and 5 angles.",
  ),
  ShapeInfo(
    name: "Hexagon",
    image: "assets/images/hexagon.png",
    description: "6 sides and 6 angles.",
  ),
  ShapeInfo(
    name: "Heptagon",
    image: "assets/images/heptagon.png",
    description: "7 sides and 7 angles.",
  ),
  ShapeInfo(
    name: "Octagon",
    image: "assets/images/octagon.png",
    description: "8 sides and 8 angles.",
  ),
  ShapeInfo(
    name: "Nonagon",
    image: "assets/images/nonagon.png",
    description: "9 sides and 9 angles.",
  ),
  ShapeInfo(
    name: "Decagon",
    image: "assets/images/decagon.png",
    description: "10 sides and 10 angles.",
  ),
];
