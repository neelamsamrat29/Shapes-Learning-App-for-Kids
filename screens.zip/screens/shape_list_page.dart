import 'package:flutter/material.dart';
import '../data/shapes_data.dart';
import 'shape_detail_page.dart';

class ShapeListPage extends StatelessWidget {
  const ShapeListPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("All Shapes")),
      body: ListView.builder(
        itemCount: shapeList.length,
        itemBuilder: (context, index) {
          final shape = shapeList[index];
          return ListTile(
            leading: Image.asset(shape.image, width: 50),
            title: Text(shape.name),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(
                builder: (_) => ShapeDetailPage(shape: shape),
              ));
            },
          );
        },
      ),
    );
  }
}
