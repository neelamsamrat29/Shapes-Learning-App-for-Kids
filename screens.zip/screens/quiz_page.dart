import 'package:flutter/material.dart';
import '../data/quiz_questions.dart';

class QuizPage extends StatefulWidget {
  const QuizPage({super.key});

  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  int currentIndex = 0;
  int score = 0;

  void checkAnswer(String selected) {
    if (selected == quizQuestions[currentIndex].answer) {
      score++;
    }

    setState(() {
      currentIndex++;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (currentIndex >= quizQuestions.length) {
      return Scaffold(
        body: Center(
          child: Text("Quiz Finished!\nYour score: $score/${quizQuestions.length}",
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 24),
          ),
        ),
      );
    }

    final question = quizQuestions[currentIndex];

    return Scaffold(
      appBar: AppBar(title: const Text("Shape Quiz")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Text(question.question, style: const TextStyle(fontSize: 20)),
            const SizedBox(height: 20),
            ...question.options.map((opt) => ElevatedButton(
              onPressed: () => checkAnswer(opt),
              child: Text(opt),
            )),
          ],
        ),
      ),
    );
  }
}
