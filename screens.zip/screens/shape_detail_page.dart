import 'package:flutter/material.dart';
import '../models/shape_info.dart';

class ShapeDetailPage extends StatelessWidget {
  final ShapeInfo shape;
  const ShapeDetailPage({super.key, required this.shape});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(shape.name)),
      body: Column(
        children: [
          Image.asset(shape.image, height: 200),
          const SizedBox(height: 20),
          Text(shape.description, style: const TextStyle(fontSize: 18)),
        ],
      ),
    );
  }
}
