class QuizQuestion {
  final String question;
  final List<String> options;
  final String answer;

  QuizQuestion({required this.question, required this.options, required this.answer});
}

final List<QuizQuestion> quizQuestions = [
  QuizQuestion(
    question: "Which shape has 4 equal sides and 4 right angles?",
    options: ["Square", "Rectangle", "Rhombus"],
    answer: "Square",
  ),
  QuizQuestion(
    question: "Which triangle has one 90° angle?",
    options: ["Right Triangle", "Acute Triangle", "Obtuse Triangle"],
    answer: "Right Triangle",
  ),
  QuizQuestion(
    question: "How many sides does a pentagon have?",
    options: ["4", "5", "6"],
    answer: "5",
  ),
];
